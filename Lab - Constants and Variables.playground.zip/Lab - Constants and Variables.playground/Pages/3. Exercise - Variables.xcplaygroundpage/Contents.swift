/*:
 ## Exercise - Variables
 
 Declare a variable `schooling` and set it to the number of years of school that you have completed. Print `schooling` to the console.
 */
var schooling = 12
print("schooling")

print(schooling)
schooling = 13

print("this code does work because the variable keeps changing.")

//: [Previous](@previous)  |  page 3 of 10  |  [Next: App Exercise - Step Count](@next)
